/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package darsbbqapp;

import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class EditAccountPanel extends javax.swing.JPanel {

    public AccountDetails AccountToEdit;
    public JPanel mainParent;
    public CardLayout cl;
    public String ErrorMessage;
    public EditAccountPanel(AccountDetails account, JPanel MainParent,CardLayout CL) {
        AccountToEdit = account;
        mainParent = MainParent;
        cl = CL;
        initComponents();
        LastNameTxtBox.setText(AccountToEdit.LastName);
        FirstNameTxtBox.setText(AccountToEdit.FirstName);
        DobDatePicker.setDate(AccountToEdit.DoB);
        GenderComboBox.setSelectedItem(AccountToEdit.Gender);
        JobTxtBox.setText(AccountToEdit.JobTitle);
        DeptTxtBox.setText(AccountToEdit.Department);
        EmailTxtBox.setText(AccountToEdit.Email);
        PhoneTxtBox.setText(AccountToEdit.PhoneNum);
        WEmailTxtBox.setText(AccountToEdit.WEmail);
        WPhoneTxtBox.setText(AccountToEdit.WPhoneNum);
        UsernameTxtBox.setText(AccountToEdit.Username);
        PasswordTxtBox.setText(AccountToEdit.Password);
        ConfirmPassTxtBox.setText(AccountToEdit.Password);

    }
    public boolean CheckError(){
        boolean Error = false;
        ErrorMessage = "";       
        if (LastNameTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", LastName";
            LastNameTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (FirstNameTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", First Name";
            FirstNameTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (DobDatePicker.getDate().equals(null)){
            Error = true;
            ErrorMessage += ", Date of Birth";
            DobDatePicker.setBorder(BorderFactory.createLineBorder(Color.red));
        }                    
        if (PhoneTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Phone Number";
            PhoneTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (EmailTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Email Address";
            EmailTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (DeptTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Department";
            DeptTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (JobTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Job Title";
            JobTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (WPhoneTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Work Phone Number";
            WPhoneTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }      
        if (WEmailTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Work Email Address";
            WEmailTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (UsernameTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Username";
            UsernameTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (PasswordTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Password";
            PasswordTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (ConfirmPassTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Confirm Password";
            ConfirmPassTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (ErrorMessage.length() > 5) ErrorMessage = ErrorMessage.substring(2)+" are empty!";
        
        if (!ConfirmPassTxtBox.getText().equals(PasswordTxtBox.getText())){
            Error = true;
            if (ErrorMessage.length() < 5) ErrorMessage += "Confirm password must be the same with the original password";
            else ErrorMessage += ", Confirm password must be the same with the original password";
            ConfirmPassTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        
        return Error;       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jlabel12 = new javax.swing.JLabel();
        DobDatePicker = new com.toedter.calendar.JDateChooser();
        JobTxtBox = new javax.swing.JTextField();
        GenderComboBox = new javax.swing.JComboBox<>();
        DeptTxtBox = new javax.swing.JTextField();
        EmailTxtBox = new javax.swing.JTextField();
        PhoneTxtBox = new javax.swing.JTextField();
        WEmailTxtBox = new javax.swing.JTextField();
        WPhoneTxtBox = new javax.swing.JTextField();
        UsernameTxtBox = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        PasswordTxtBox = new javax.swing.JPasswordField();
        jLabel9 = new javax.swing.JLabel();
        ConfirmPassTxtBox = new javax.swing.JPasswordField();
        FirstNameTxtBox = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel10 = new javax.swing.JLabel();
        LastNameTxtBox = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        ErrorLbl = new javax.swing.JLabel();

        jTextField1.setText("jTextField1");

        setBackground(new java.awt.Color(255, 204, 0));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 10, true));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Date of Birth");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Gender");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("Position");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Personal Contacts");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setText("Work Contacts");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("Username");

        jlabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jlabel12.setText("Department");

        JobTxtBox.setText("jTextField1");

        GenderComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female", "Other" }));

        DeptTxtBox.setText("jTextField2");

        EmailTxtBox.setText("jTextField3");

        PhoneTxtBox.setText("jTextField4");

        WEmailTxtBox.setText("jTextField5");

        WPhoneTxtBox.setText("jTextField6");

        UsernameTxtBox.setText("jTextField7");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setText("Password");

        PasswordTxtBox.setText("jPasswordField1");
        PasswordTxtBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PasswordTxtBoxActionPerformed(evt);
            }
        });

        jLabel9.setText("Confirm Password");

        FirstNameTxtBox.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        FirstNameTxtBox.setText("jTextField1");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setText("Last Name");

        LastNameTxtBox.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        LastNameTxtBox.setText("jTextField1");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setText("First Name");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(PhoneTxtBox, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(EmailTxtBox, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(DobDatePicker, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                            .addComponent(GenderComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addGap(18, 18, 18)
                                    .addComponent(JobTxtBox))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addGap(19, 19, 19)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(DeptTxtBox, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 182, Short.MAX_VALUE)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jlabel12)
                                            .addGap(0, 0, Short.MAX_VALUE)))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel5)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(WEmailTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(WPhoneTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(PasswordTxtBox)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel8))
                                .addGap(0, 89, Short.MAX_VALUE))
                            .addComponent(ConfirmPassTxtBox)
                            .addComponent(UsernameTxtBox))
                        .addGap(56, 56, 56))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator1)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(LastNameTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel11)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(FirstNameTxtBox))))
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LastNameTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(FirstNameTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 4, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel6))
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DobDatePicker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(JobTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(UsernameTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jlabel12)
                    .addComponent(jLabel8))
                .addGap(7, 7, 7)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(GenderComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DeptTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PasswordTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(ConfirmPassTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EmailTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(WEmailTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PhoneTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(WPhoneTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(35, Short.MAX_VALUE))
        );

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/darsbbqapp/Photos/icons8-save-20.png"))); // NOI18N
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/darsbbqapp/Photos/icons8-cancel-20.png"))); // NOI18N
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });

        ErrorLbl.setForeground(new java.awt.Color(255, 0, 0));
        ErrorLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(261, 261, 261)
                        .addComponent(ErrorLbl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(103, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton2)
                        .addComponent(jButton3))
                    .addComponent(ErrorLbl, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void PasswordTxtBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PasswordTxtBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PasswordTxtBoxActionPerformed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        boolean confirm = CheckError();
        if (confirm){
            ErrorLbl.setText(ErrorMessage);
            return;
        }
        try{          
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
            Statement st = con.createStatement();
            String query="update employee set LastName = ?, FirstName = ?, Gender = ?, DateOfBirth = ?, ContactNum = ?, Email = ?, Department = ?, JobTitle = ?, WorkEmail = ?, WorkPNum = ? where EmployeeId = ?";
            java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);
            prepstmnt.setString(1, LastNameTxtBox.getText());
            prepstmnt.setString(2, FirstNameTxtBox.getText());
            prepstmnt.setString(3, GenderComboBox.getSelectedItem().toString());
            prepstmnt.setDate(4, new java.sql.Date(DobDatePicker.getDate().getTime()));
            prepstmnt.setString(5, PhoneTxtBox.getText());
            prepstmnt.setString(6, EmailTxtBox.getText());
            prepstmnt.setString(7, DeptTxtBox.getText());
            prepstmnt.setString(8, JobTxtBox.getText());
            prepstmnt.setString(9, WEmailTxtBox.getText());
            prepstmnt.setString(10, WPhoneTxtBox.getText());
            prepstmnt.setString(11, String.valueOf(AccountToEdit.EmployeeId));                              
            prepstmnt.executeUpdate();
            query = "update account set Username = ?, Password = ?  where AccountID = ?";
            prepstmnt = con.prepareStatement(query);
            prepstmnt.setString(1, UsernameTxtBox.getText());
            prepstmnt.setString(2, PasswordTxtBox.getText());
            prepstmnt.setString(3, String.valueOf(AccountToEdit.AccountId));
            prepstmnt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Your account has been successfully updated!");
            mainParent.remove(this);
            cl.show(mainParent, "2");                   
        } catch (ClassNotFoundException | SQLException e1){
            e1.printStackTrace();
        }
        
    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
        int answer = JOptionPane.showConfirmDialog(null, "Are you sure? Changes will not be saved...", "Cancel Confirmation", JOptionPane.YES_NO_OPTION);
        if (answer == 0){
            mainParent.remove(this);
            cl.show(mainParent, "2");
        }         
    }//GEN-LAST:event_jButton3MouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField ConfirmPassTxtBox;
    private javax.swing.JTextField DeptTxtBox;
    private com.toedter.calendar.JDateChooser DobDatePicker;
    private javax.swing.JTextField EmailTxtBox;
    private javax.swing.JLabel ErrorLbl;
    private javax.swing.JTextField FirstNameTxtBox;
    private javax.swing.JComboBox<String> GenderComboBox;
    private javax.swing.JTextField JobTxtBox;
    private javax.swing.JTextField LastNameTxtBox;
    private javax.swing.JPasswordField PasswordTxtBox;
    private javax.swing.JTextField PhoneTxtBox;
    private javax.swing.JTextField UsernameTxtBox;
    private javax.swing.JTextField WEmailTxtBox;
    private javax.swing.JTextField WPhoneTxtBox;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel jlabel12;
    // End of variables declaration//GEN-END:variables
}
