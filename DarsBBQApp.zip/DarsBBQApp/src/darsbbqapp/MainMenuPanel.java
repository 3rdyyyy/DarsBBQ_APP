
package darsbbqapp;

import java.awt.*;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class MainMenuPanel extends javax.swing.JPanel {
    
    public CardLayout cl = new CardLayout();
    public JPanel mainParent;
    public CardLayout mainCL;
    public JFrame mainFrame;
    public Account AccountIn;


    public MainMenuPanel(Account accountIn,JFrame MainFrame,JPanel MainParent, CardLayout MainCL) {
        AccountIn = accountIn;
        mainParent = MainParent;
        mainCL = MainCL;
        mainFrame = MainFrame;
        initComponents();
        MyInitComponents();        
        ToolsBtn.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0,5,0,0,Color.white),BorderFactory.createEmptyBorder(0, 20, 0, 0)));
    }
    public void MyInitComponents(){
        ContPanel.setLayout(cl);       
        ContPanel.add(new ToolsPanel(mainParent,mainCL),"1");
        ContPanel.add(new AccountPanel(AccountIn, cl,ContPanel),"2");
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        ToolsBtn = new javax.swing.JButton();
        AccountBtn = new javax.swing.JButton();
        LogOutBtn = new javax.swing.JButton();
        ContPanel = new javax.swing.JPanel();

        setBackground(new java.awt.Color(255, 204, 0));

        jPanel1.setBackground(new java.awt.Color(255, 153, 0));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/darsbbqapp/Photos/Dars Background No Background small.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Showcard Gothic", 0, 43)); // NOI18N
        jLabel2.setText("DAR's BBQ Management System");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addContainerGap(65, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(15, 15, 15))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(54, 54, 54))))
        );

        jPanel2.setBackground(new java.awt.Color(255, 204, 0));

        ToolsBtn.setBackground(new java.awt.Color(255, 204, 0));
        ToolsBtn.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        ToolsBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/darsbbqapp/Photos/icons8-tools-30.png"))); // NOI18N
        ToolsBtn.setText("Tools");
        ToolsBtn.setAlignmentX(0.5F);
        ToolsBtn.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 20, 1, 1));
        ToolsBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ToolsBtn.setFocusPainted(false);
        ToolsBtn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        ToolsBtn.setIconTextGap(64);
        ToolsBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ToolsBtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ToolsBtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ToolsBtnMouseExited(evt);
            }
        });
        ToolsBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ToolsBtnActionPerformed(evt);
            }
        });

        AccountBtn.setBackground(new java.awt.Color(255, 204, 0));
        AccountBtn.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        AccountBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/darsbbqapp/Photos/icons8-account-30.png"))); // NOI18N
        AccountBtn.setText("Account");
        AccountBtn.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 20, 1, 1));
        AccountBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        AccountBtn.setFocusPainted(false);
        AccountBtn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        AccountBtn.setIconTextGap(50);
        AccountBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AccountBtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                AccountBtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                AccountBtnMouseExited(evt);
            }
        });

        LogOutBtn.setBackground(new java.awt.Color(255, 204, 0));
        LogOutBtn.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        LogOutBtn.setForeground(new java.awt.Color(255, 0, 0));
        LogOutBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/darsbbqapp/Photos/icons8-sign-out-30 (1).png"))); // NOI18N
        LogOutBtn.setText("Sign Out");
        LogOutBtn.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 22, 1, 1));
        LogOutBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        LogOutBtn.setFocusPainted(false);
        LogOutBtn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        LogOutBtn.setIconTextGap(42);
        LogOutBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogOutBtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                LogOutBtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                LogOutBtnMouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ToolsBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 284, Short.MAX_VALUE)
            .addComponent(AccountBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(LogOutBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(ToolsBtn)
                .addGap(27, 27, 27)
                .addComponent(AccountBtn)
                .addGap(30, 30, 30)
                .addComponent(LogOutBtn)
                .addContainerGap(211, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout ContPanelLayout = new javax.swing.GroupLayout(ContPanel);
        ContPanel.setLayout(ContPanelLayout);
        ContPanelLayout.setHorizontalGroup(
            ContPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        ContPanelLayout.setVerticalGroup(
            ContPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ContPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ContPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void ToolsBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ToolsBtnMouseClicked
        cl.show(ContPanel,"1");       
        ToolsBtn.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0,5,0,0,Color.white),BorderFactory.createEmptyBorder(0, 20, 0, 0)));
        AccountBtn.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
    }//GEN-LAST:event_ToolsBtnMouseClicked

    private void ToolsBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ToolsBtnMouseEntered
        ToolsBtn.setBackground(Color.lightGray);
        ToolsBtn.setForeground(Color.white);
    }//GEN-LAST:event_ToolsBtnMouseEntered

    private void ToolsBtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ToolsBtnMouseExited
        ToolsBtn.setBackground(new Color(255,204,0));
        ToolsBtn.setForeground(Color.black);
    }//GEN-LAST:event_ToolsBtnMouseExited

    private void AccountBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AccountBtnMouseClicked
        cl.show(ContPanel,"2");
        AccountBtn.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0,5,0,0,Color.white),BorderFactory.createEmptyBorder(0, 20, 0, 0)));
        ToolsBtn.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
    }//GEN-LAST:event_AccountBtnMouseClicked

    private void AccountBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AccountBtnMouseEntered
        AccountBtn.setBackground(Color.lightGray);
        AccountBtn.setForeground(Color.white);
    }//GEN-LAST:event_AccountBtnMouseEntered

    private void AccountBtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AccountBtnMouseExited
        AccountBtn.setBackground(new Color(255,204,0));
        AccountBtn.setForeground(Color.black);
    }//GEN-LAST:event_AccountBtnMouseExited

    private void LogOutBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogOutBtnMouseEntered
        LogOutBtn.setBackground(Color.RED);
        LogOutBtn.setForeground(Color.white);
    }//GEN-LAST:event_LogOutBtnMouseEntered

    private void LogOutBtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogOutBtnMouseExited
        LogOutBtn.setBackground(new Color(255,204,0));
        LogOutBtn.setForeground(Color.red);
    }//GEN-LAST:event_LogOutBtnMouseExited

    private void LogOutBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogOutBtnMouseClicked
        JFrame logout = new Login();
        logout.setLocationRelativeTo(null);
        logout.setVisible(true);
        mainFrame.setVisible(false);
    }//GEN-LAST:event_LogOutBtnMouseClicked

    private void ToolsBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ToolsBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ToolsBtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AccountBtn;
    private javax.swing.JPanel ContPanel;
    private javax.swing.JButton LogOutBtn;
    private javax.swing.JButton ToolsBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
