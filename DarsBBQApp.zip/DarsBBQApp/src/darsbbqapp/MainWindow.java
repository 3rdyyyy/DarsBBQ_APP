
package darsbbqapp;

import javax.swing.*;

class MainWindow {
    public static JFrame mainWindow;
    public MainWindow() {
        mainWindow = new Login();
        mainWindow.setTitle("DAR's BBQ Manager");
        mainWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        mainWindow.setSize(1000,800);
        mainWindow.setResizable(false);
        mainWindow.setLocationRelativeTo(null);
    }
    
    public void show(){
        mainWindow.setVisible(true);       
    }   
}
