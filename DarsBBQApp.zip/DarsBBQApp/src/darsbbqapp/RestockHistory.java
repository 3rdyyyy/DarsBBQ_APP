
package darsbbqapp;

import java.awt.CardLayout;
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.Date;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


public class RestockHistory extends javax.swing.JPanel {

    public JPanel mainParent;
    public CardLayout mainCL;
    public String ErrorMessage;
    public int RecordToRemove;
    public RestockHistory(JPanel MainParent, CardLayout MainCL) {
        initComponents();
        mainParent = MainParent;
        mainCL = MainCL;
        SearchInvTxtBox.setText("");
        NotesTxtBox.setText("");
        SearchHistory();
        LoadItems();
        SearchInvTxtBox.getDocument().addDocumentListener(new DocumentListener() {
        public void changedUpdate(DocumentEvent e) {
            warn();
        }
        public void removeUpdate(DocumentEvent e) {
            warn();
        }
        public void insertUpdate(DocumentEvent e) {
            warn();
        }
        public void warn() {
            SearchHistory();
        }
        }); 
    }
    public boolean CheckError()
    {
        boolean Error = false;
        ErrorMessage = "";
        if ("None".equals(ItemComboBox.getSelectedItem().toString())){
            Error = true;
            ErrorMessage += ", Item";
            ItemComboBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }                                        
        return Error;       
    }
    
    private void SearchHistory(){
        String Search = "%"+ SearchInvTxtBox.getText() + "%";
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
            Statement st = con.createStatement();
            String query="select * from restock where Name like ? or Date = ? order by Date";
            java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);
            for (int i = 1;i<3;i++){
                prepstmnt.setString(i, Search);               
            }           
            ResultSet rs= prepstmnt.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            DefaultTableModel model = (DefaultTableModel) RecordList.getModel();
            String[] colName = new String[5];
            colName[0]="Id";
            colName[1]="Name";
            colName[2]="Notes";
            colName[3]="Date Recorded";            
            colName[4]="Amount";            
            model.setColumnIdentifiers(colName);
            String ItemId,Name,Notes,date,stock;
            model.setRowCount(0);
            while(rs.next()){
                ItemId=rs.getString(1);
                Name=rs.getString(3);
                Notes=rs.getString(4);
                date=rs.getString(5);              
                stock=rs.getString(6);              
                String[] row= {ItemId,Name,Notes,date,stock};
                model.addRow(row);
            }
            st.close();
            con.close();
            
        } catch (ClassNotFoundException | SQLException e1){
            e1.printStackTrace();
        }
    }
    private void LoadItems(){
        ItemComboBox.removeAllItems();
        ItemComboBox.addItem("None");
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
            Statement st = con.createStatement();
            String query="select Name from inventory";
            java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);                   
            ResultSet rs= prepstmnt.executeQuery();                                                              
            while(rs.next()){
                String a = rs.getString(1);
                ItemComboBox.addItem(a);                          
            }
            st.close();
            con.close();
            
        } catch (ClassNotFoundException | SQLException e1){
            e1.printStackTrace();
        }
        
        
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        RecordList = new javax.swing.JTable();
        BackBtn = new javax.swing.JButton();
        SearchInvTxtBox = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        RemoveBtn = new javax.swing.JButton();
        PrintBtn = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        AddBtn = new javax.swing.JButton();
        ErrorLbl = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        NotesTxtBox = new javax.swing.JTextArea();
        ItemComboBox = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        AmountSpinner = new javax.swing.JSpinner();

        setBackground(new java.awt.Color(255, 153, 0));
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        jPanel1.setOpaque(false);

        RecordList.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        RecordList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RecordListMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(RecordList);

        BackBtn.setText("<");
        BackBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BackBtnMouseClicked(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/darsbbqapp/Photos/icons8-search-20.png"))); // NOI18N

        RemoveBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/darsbbqapp/Photos/icons8-remove-20.png"))); // NOI18N
        RemoveBtn.setToolTipText("Delete a selected row.");
        RemoveBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RemoveBtnMouseClicked(evt);
            }
        });

        PrintBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/darsbbqapp/Photos/icons8-print-20.png"))); // NOI18N
        PrintBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PrintBtnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(BackBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SearchInvTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PrintBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(RemoveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 861, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(BackBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(RemoveBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel1)
                            .addComponent(PrintBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(8, 8, 8))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(SearchInvTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel2.setOpaque(false);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Add Record");

        jLabel3.setText("Item :");

        jLabel4.setText("Notes :");

        AddBtn.setText("Add");
        AddBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddBtnMouseClicked(evt);
            }
        });
        AddBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddBtnActionPerformed(evt);
            }
        });

        ErrorLbl.setForeground(new java.awt.Color(255, 0, 0));
        ErrorLbl.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);

        NotesTxtBox.setColumns(20);
        NotesTxtBox.setRows(5);
        jScrollPane2.setViewportView(NotesTxtBox);

        ItemComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ItemComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemComboBoxActionPerformed(evt);
            }
        });

        jLabel5.setText("Amount :");

        AmountSpinner.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 794, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ItemComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(AmountSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(118, 118, 118))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabel2)
                        .addGap(277, 277, 277)
                        .addComponent(ErrorLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(AddBtn)))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(AddBtn)
                            .addComponent(ErrorLbl))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(ItemComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5)
                        .addComponent(AmountSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void AddBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddBtnActionPerformed
        try{
            boolean error = CheckError();
            if (error){
                ErrorLbl.setText(ErrorMessage.substring(2)+" are empty!");
                return;
            }
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
            Statement st = con.createStatement();
            String query="Select InventoryId,Stock from inventory where Name = ?";
            java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);
            prepstmnt.setString(1, ItemComboBox.getSelectedItem().toString());                                   
            ResultSet rs = prepstmnt.executeQuery();
            int inventoryid = 0, stock = 0;
            while(rs.next()){
                inventoryid =rs.getInt(1);
                stock = rs.getInt(2);
            }
            query="insert into restock(InventoryId,Name,Notes,Date,Amount) values(?,?,?,?,?)";
            prepstmnt = con.prepareStatement(query);
            prepstmnt.setInt(1, inventoryid);
            prepstmnt.setString(2, ItemComboBox.getSelectedItem().toString());
            prepstmnt.setString(3, NotesTxtBox.getText());
            prepstmnt.setDate(4, new java.sql.Date(System.currentTimeMillis())); 
            prepstmnt.setInt(5,(Integer)AmountSpinner.getValue());
            prepstmnt.execute();
            query="update inventory set Stock = ? where InventoryId = ?";
            prepstmnt = con.prepareStatement(query);
            prepstmnt.setInt(1, stock + (Integer)AmountSpinner.getValue());
            prepstmnt.setInt(2, inventoryid);
            prepstmnt.executeUpdate();            
            JOptionPane.showMessageDialog(null, "Record added");
            ItemComboBox.setSelectedIndex(0);
            NotesTxtBox.setText("");
            SearchHistory();
        } catch (ClassNotFoundException | SQLException e1){
            e1.printStackTrace();
        }
    }//GEN-LAST:event_AddBtnActionPerformed

    private void BackBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BackBtnMouseClicked
        mainCL.show(mainParent, "1");
    }//GEN-LAST:event_BackBtnMouseClicked

    private void RemoveBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RemoveBtnMouseClicked
        int answer = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete Record with the ID "+ String.valueOf(RecordToRemove) + "? data will be lost forever...", "Delete Confirmation", JOptionPane.YES_NO_OPTION);
        if (answer == 0){
            try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
                Statement st = con.createStatement();
                String query="delete from restock where RestockId = ?";
                java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);
                prepstmnt.setInt(1,RecordToRemove);
                prepstmnt.executeUpdate();
                JOptionPane.showMessageDialog(null, "Record with the ID "+ String.valueOf(RecordToRemove)+" is now deleted");
                SearchHistory();
            }catch (ClassNotFoundException | SQLException e1){
                e1.printStackTrace();
            }
        }
    }//GEN-LAST:event_RemoveBtnMouseClicked

    private void AddBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddBtnMouseClicked
        
    }//GEN-LAST:event_AddBtnMouseClicked

    private void RecordListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RecordListMouseClicked
        int i = RecordList.getSelectedRow();
        TableModel model = RecordList.getModel();
        int selectedId = Integer.parseInt(model.getValueAt(i,0).toString());
        RecordToRemove = selectedId;
    }//GEN-LAST:event_RecordListMouseClicked

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        SearchHistory();
        LoadItems();
    }//GEN-LAST:event_formComponentShown

    private void ItemComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ItemComboBoxActionPerformed

    private void PrintBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PrintBtnMouseClicked
        MessageFormat header = new MessageFormat("Restock History Records");
        try{
            PrintRequestAttributeSet set = new HashPrintRequestAttributeSet();
            RecordList.print(JTable.PrintMode.FIT_WIDTH, header,null, true, set, true);
            JOptionPane.showMessageDialog(null, "Printed Successfully");            
        }catch (java.awt.print.PrinterException e) {
            JOptionPane.showMessageDialog(null, "Print Failed", "Print Error", JOptionPane.ERROR_MESSAGE); 
        }     
        
    }//GEN-LAST:event_PrintBtnMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddBtn;
    private javax.swing.JSpinner AmountSpinner;
    private javax.swing.JButton BackBtn;
    private javax.swing.JLabel ErrorLbl;
    private javax.swing.JComboBox<String> ItemComboBox;
    private javax.swing.JTextArea NotesTxtBox;
    private javax.swing.JButton PrintBtn;
    private javax.swing.JTable RecordList;
    private javax.swing.JButton RemoveBtn;
    private javax.swing.JTextField SearchInvTxtBox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
