/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package darsbbqapp;

/**
 *
 * @author Martin
 */
public class InventoryItem {
    public int InventoryId;
    public String Name;
    public String Description;
    public String Weight;
    public int Stock;
    
    public InventoryItem(int inventoryId, String name, String description,String weight,int stock){
        InventoryId = inventoryId;
        Name = name;
        Description = description;
        Weight = weight;
        Stock = stock;       
    }
    
}
