/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package darsbbqapp;

/**
 *
 * @author Martin
 */
public class Account {
    public int AccountId;  
    public boolean IsAdmin;
    
    public Account(int accountId, int isAdmin){
        AccountId = accountId;       
        if (isAdmin == 1) IsAdmin = true;
        else IsAdmin = false;
        
    }
    
}
