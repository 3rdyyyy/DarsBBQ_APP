/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package darsbbqapp;

import java.awt.CardLayout;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author Martin
 */
public class InventoryPanel extends javax.swing.JPanel {

    public JPanel mainParent;
    public CardLayout mainCL;
    public InventoryItem SelectedItem;    
    public InventoryPanel(JPanel MainParent, CardLayout MainCL) {
        initComponents();
        mainParent = MainParent;
        mainCL = MainCL;
        SearchInventory();
        SearchInvTxtBox.setText("");
        SearchInvTxtBox.getDocument().addDocumentListener(new DocumentListener() {
        public void changedUpdate(DocumentEvent e) {
            warn();
        }
        public void removeUpdate(DocumentEvent e) {
            warn();
        }
        public void insertUpdate(DocumentEvent e) {
            warn();
        }
        public void warn() {
            SearchInventory();
        }
        });   
    }

    private void SearchInventory(){
        String Search = "%"+ SearchInvTxtBox.getText() + "%";
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
            Statement st = con.createStatement();
            String query="select * from inventory where Name like ? or Weight like ? or Stock like ? ";
            java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);
            for (int i = 1;i<4;i++){
                prepstmnt.setString(i, Search);               
            }           
            ResultSet rs= prepstmnt.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            DefaultTableModel model = (DefaultTableModel) InventoryList.getModel();
            String[] colName = new String[4];
            colName[0]="ItemId";
            colName[1]="Name";
            colName[2]="Weight";
            colName[3]="Stock";            
            model.setColumnIdentifiers(colName);
            String ItemId,Name,Weight,Stock;
            model.setRowCount(0);
            while(rs.next()){
                ItemId=rs.getString(1);
                Name=rs.getString(2);
                Weight=rs.getString(4);
                Stock=rs.getString(5);              
                String[] row= {ItemId,Name,Weight,Stock};
                model.addRow(row);
            }
            st.close();
            con.close();
            
        } catch (ClassNotFoundException | SQLException e1){
            e1.printStackTrace();
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        InventoryList = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        SearchInvTxtBox = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        BackButton = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        InventoryIdLbl = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        NameLbl = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        WeightLbl = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        StockLbl = new javax.swing.JLabel();
        EditBtn = new javax.swing.JButton();
        RemoveBtn = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        DescriptionText = new javax.swing.JTextArea();

        setBackground(new java.awt.Color(255, 153, 0));
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });
        setLayout(new java.awt.GridLayout(1, 0));

        jPanel1.setOpaque(false);

        InventoryList.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "InventoryId", "Name", "Weight", "Stock"
            }
        ));
        InventoryList.setMinimumSize(new java.awt.Dimension(1000, 100));
        InventoryList.setRowHeight(25);
        InventoryList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                InventoryListMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(InventoryList);

        jPanel4.setOpaque(false);

        SearchInvTxtBox.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                SearchInvTxtBoxPropertyChange(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/darsbbqapp/Photos/icons8-search-20.png"))); // NOI18N

        BackButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BackButton.setText("<");
        BackButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BackButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BackButtonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(BackButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SearchInvTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 8, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(BackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SearchInvTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/darsbbqapp/Photos/plus-icon-21715 (2).png"))); // NOI18N
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 391, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 485, Short.MAX_VALUE)
                .addContainerGap())
        );

        add(jPanel1);

        jPanel2.setOpaque(false);

        InventoryIdLbl.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        InventoryIdLbl.setForeground(new java.awt.Color(255, 102, 0));
        InventoryIdLbl.setText("Inventory Id");

        jLabel1.setBackground(new java.awt.Color(102, 102, 102));
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("Name ");

        NameLbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        NameLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        NameLbl.setText("Name ");

        jLabel2.setBackground(new java.awt.Color(102, 102, 102));
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setText("Description ");

        jLabel3.setBackground(new java.awt.Color(102, 102, 102));
        jLabel3.setForeground(new java.awt.Color(102, 102, 102));
        jLabel3.setText("Weight ");

        WeightLbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        WeightLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WeightLbl.setText("Weight");

        jLabel4.setBackground(new java.awt.Color(102, 102, 102));
        jLabel4.setForeground(new java.awt.Color(102, 102, 102));
        jLabel4.setText("Stock ");

        StockLbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        StockLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        StockLbl.setText("Stock");

        EditBtn.setText("Edit");
        EditBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EditBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EditBtnMouseClicked(evt);
            }
        });

        RemoveBtn.setForeground(new java.awt.Color(255, 0, 51));
        RemoveBtn.setText("Remove");
        RemoveBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        RemoveBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RemoveBtnMouseClicked(evt);
            }
        });

        DescriptionText.setBackground(new java.awt.Color(242, 242, 242));
        DescriptionText.setColumns(20);
        DescriptionText.setLineWrap(true);
        DescriptionText.setRows(5);
        DescriptionText.setFocusable(false);
        jScrollPane2.setViewportView(DescriptionText);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 86, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(WeightLbl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(StockLbl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(0, 319, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(NameLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(InventoryIdLbl))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(RemoveBtn)
                        .addGap(75, 75, 75)
                        .addComponent(EditBtn)
                        .addGap(99, 99, 99))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(InventoryIdLbl)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(NameLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(WeightLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(StockLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 242, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EditBtn)
                    .addComponent(RemoveBtn))
                .addGap(26, 26, 26))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        add(jPanel2);
    }// </editor-fold>//GEN-END:initComponents

    private void BackButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BackButtonMouseClicked
        mainCL.show(mainParent, "1");
    }//GEN-LAST:event_BackButtonMouseClicked

    private void SearchInvTxtBoxPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_SearchInvTxtBoxPropertyChange

    }//GEN-LAST:event_SearchInvTxtBoxPropertyChange

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
        mainParent.add(new AddInventory(mainParent,mainCL),"NewAddInventory");
        mainCL.show(mainParent, "NewAddInventory");
    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void EditBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EditBtnMouseClicked
        if (SelectedItem != null){
            mainParent.add(new EditInventory(SelectedItem,mainParent,mainCL),"NewEditInventory");
            mainCL.show(mainParent, "NewEditInventory");
        }
    }//GEN-LAST:event_EditBtnMouseClicked

    private void RemoveBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RemoveBtnMouseClicked
        int answer = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete Employee with the ID "+SelectedItem.Name+ "? Employee data will be lost forever...", "Delete Confirmation", JOptionPane.YES_NO_OPTION);
        if (answer == 0){
            try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
                Statement st = con.createStatement();
                String query="delete from inventory where InventoryId = ?";
                java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);
                prepstmnt.setInt(1,SelectedItem.InventoryId);
                prepstmnt.executeUpdate();
                JOptionPane.showMessageDialog(null, "Item named "+SelectedItem.Name+" is now deleted from records...");
                SearchInventory();
            }catch (ClassNotFoundException | SQLException e1){
                e1.printStackTrace();
            }
        }
    }//GEN-LAST:event_RemoveBtnMouseClicked

    private void InventoryListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_InventoryListMouseClicked
        int i = InventoryList.getSelectedRow();
        TableModel model = InventoryList.getModel();
        int selectedId = Integer.parseInt(model.getValueAt(i,0).toString());
        int inventoryId = 0, stock = 0;
        String name = null, description = null,weight = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
            Statement st = con.createStatement();
            String query="select * from inventory where InventoryId = ?"; 
            java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);
            prepstmnt.setInt(1,selectedId);
            ResultSet rs= prepstmnt.executeQuery();                       
            if(rs.next()){
                inventoryId = rs.getInt(1);
                name = rs.getString(2);
                description = rs.getString(3);
                weight = rs.getString(4);
                stock = rs.getInt(5);                   
            }
            InventoryIdLbl.setText(String.valueOf(inventoryId));
            NameLbl.setText(name);
            DescriptionText.setText(description);
            WeightLbl.setText(weight);
            StockLbl.setText(String.valueOf(stock));           
            SelectedItem = new InventoryItem(inventoryId,name,description,weight,stock);
            }catch (ClassNotFoundException | SQLException e1){
            e1.printStackTrace();
        }
    }//GEN-LAST:event_InventoryListMouseClicked

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        SearchInventory();
    }//GEN-LAST:event_formComponentShown


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackButton;
    private javax.swing.JTextArea DescriptionText;
    private javax.swing.JButton EditBtn;
    private javax.swing.JLabel InventoryIdLbl;
    private javax.swing.JTable InventoryList;
    private javax.swing.JLabel NameLbl;
    private javax.swing.JButton RemoveBtn;
    private javax.swing.JTextField SearchInvTxtBox;
    private javax.swing.JLabel StockLbl;
    private javax.swing.JLabel WeightLbl;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
