/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package darsbbqapp;

import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class EditEmployee extends javax.swing.JPanel {
    
    public Employee EmployeeToEdit;
    public JPanel mainParent;
    public CardLayout mainCL;
    public String ErrorMessage;

    
    public EditEmployee(Employee employee,JPanel MainParent, CardLayout MainCL) {
        initComponents();
        mainParent = MainParent;
        mainCL = MainCL;
        EmployeeToEdit = employee;
        EmployeeIdTxtBox.setText(EmployeeToEdit.EmployeeNum);
        LastNameTxtBox.setText(EmployeeToEdit.LastName);
        FirstNameTxtBox.setText(EmployeeToEdit.FirstName);
        DoBDatePicker.setDate(EmployeeToEdit.DateOfBirth);
        GenderComboBox.setSelectedItem(EmployeeToEdit.Gender);
        MaritalStatComboBox.setSelectedItem(EmployeeToEdit.MaritalStatus);
        AddressText.setText(EmployeeToEdit.Address);
        ContactNumTxtBox.setText(EmployeeToEdit.ContactNum);
        EmailAddTxtBox.setText(EmployeeToEdit.Email);
        DepartmentTxtBox.setText(EmployeeToEdit.Department);
        JobTitleTxtBox.setText(EmployeeToEdit.JobTitle);
        WContactTxtBox.setText(EmployeeToEdit.WPhone);
        DoEDatePicker.setDate(EmployeeToEdit.DateOfEmployment);
        WEmailTxtBox.setText(EmployeeToEdit.WEmail);
    }
    public boolean CheckError(){
        boolean Error = false;
        ErrorMessage = "";
        if (EmployeeIdTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", EmployeeId";
            EmployeeIdTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (LastNameTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", LastName";
            LastNameTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (FirstNameTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", First Name";
            FirstNameTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (DoBDatePicker.getDate().equals(null)){
            Error = true;
            ErrorMessage += ", Date of Birth";
            DoBDatePicker.setBorder(BorderFactory.createLineBorder(Color.red));
        }              
        if (AddressText.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Address";
            AddressText.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (ContactNumTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Contact Number";
            ContactNumTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (EmailAddTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Email Address";
            EmailAddTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (DepartmentTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Department";
            DepartmentTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (JobTitleTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Job Title";
            JobTitleTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (WContactTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Work Contact Number";
            WContactTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (DoEDatePicker.getDate().equals(null)){
            Error = true;
            ErrorMessage += ", Date of Employment";
            DoEDatePicker.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        if (WEmailTxtBox.getText().isEmpty()){
            Error = true;
            ErrorMessage += ", Work Email Address";
            WEmailTxtBox.setBorder(BorderFactory.createLineBorder(Color.red));
        }
        
        return Error;       
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        EmployeeIdTxtBox = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        LastNameTxtBox = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        FirstNameTxtBox = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        GenderComboBox = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        MaritalStatComboBox = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        AddressText = new javax.swing.JTextArea();
        jLabel10 = new javax.swing.JLabel();
        ContactNumTxtBox = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        EmailAddTxtBox = new javax.swing.JTextField();
        DoBDatePicker = new com.toedter.calendar.JDateChooser();
        jPanel3 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        DepartmentTxtBox = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        JobTitleTxtBox = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        WContactTxtBox = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        WEmailTxtBox = new javax.swing.JTextField();
        DoEDatePicker = new com.toedter.calendar.JDateChooser();
        jPanel4 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        ErrorLbl = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 204, 0));
        setLayout(new java.awt.BorderLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setText("Employee Details");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Personal Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 2, 14), new java.awt.Color(102, 102, 102))); // NOI18N

        jLabel3.setText("Employee ID :");

        jLabel4.setText("Last Name :");

        jLabel5.setText("First Name :");

        jLabel6.setText("Date of Birth :");

        jLabel7.setText("Gender :");

        GenderComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female", "Other" }));

        jLabel8.setText("Marital Status :");

        MaritalStatComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Single", "Married" }));

        jLabel9.setText(" Address :");

        AddressText.setColumns(20);
        AddressText.setRows(5);
        jScrollPane1.setViewportView(AddressText);

        jLabel10.setText("Contact Number :");

        jLabel11.setText("Email Address :");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(EmployeeIdTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGap(10, 10, 10)
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(LastNameTxtBox))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGap(9, 9, 9)
                            .addComponent(jLabel5)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(FirstNameTxtBox))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addGap(21, 21, 21)
                                    .addComponent(jLabel9))
                                .addComponent(jLabel6))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(DoBDatePicker, javax.swing.GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel7)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(GenderComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel8)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(MaritalStatComboBox, 0, 227, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel11)
                            .addComponent(jLabel10))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(EmailAddTxtBox)
                            .addComponent(ContactNumTxtBox)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(EmployeeIdTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(LastNameTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(FirstNameTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel8)
                        .addComponent(MaritalStatComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(GenderComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(DoBDatePicker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(ContactNumTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(EmailAddTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Job Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 2, 14), new java.awt.Color(102, 102, 102))); // NOI18N

        jLabel12.setText("Department :");

        DepartmentTxtBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DepartmentTxtBoxActionPerformed(evt);
            }
        });

        jLabel13.setText("Date of Employment :");

        jLabel14.setText("Job Title :");

        jLabel15.setText("Work Contact Number :");

        jLabel16.setText("Work Email :");

        WEmailTxtBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WEmailTxtBoxActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(WContactTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DoEDatePicker, javax.swing.GroupLayout.DEFAULT_SIZE, 307, Short.MAX_VALUE))
                    .addComponent(DepartmentTxtBox, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(JobTitleTxtBox)
                    .addComponent(WEmailTxtBox))
                .addGap(15, 15, 15))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(DepartmentTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(JobTitleTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel15)
                        .addComponent(WContactTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel13))
                    .addComponent(DoEDatePicker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addComponent(WEmailTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45))
        );

        jButton2.setForeground(new java.awt.Color(255, 0, 51));
        jButton2.setText("Cancel");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });

        jButton1.setText("Save Changes");
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        ErrorLbl.setForeground(new java.awt.Color(255, 0, 0));
        ErrorLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(ErrorLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(83, 83, 83)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(210, 210, 210))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addComponent(ErrorLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton1))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        add(jPanel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void DepartmentTxtBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DepartmentTxtBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DepartmentTxtBoxActionPerformed

    private void WEmailTxtBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WEmailTxtBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_WEmailTxtBoxActionPerformed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        int answer = JOptionPane.showConfirmDialog(null, "Are you sure? Changes will not be saved...", "Cancel Confirmation", JOptionPane.YES_NO_OPTION);
        if (answer == 0){
            mainParent.remove(this);
            mainCL.show(mainParent, "2");
        } 
    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        boolean error = CheckError();
        if (error){
            ErrorLbl.setText(ErrorMessage);
            return;
        }
        try{          
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
            Statement st = con.createStatement();
            String query="update employee set EmployeeNum = ?, LastName = ?, FirstName = ?, MaritalStatus = ?, Gender = ?, DateOfBirth = ?, ContactNum = ?, Email = ?, Address = ?, Department = ?, JobTitle = ?, DateOfEmployment = ?, WorkEmail = ?, WorkPNum = ? where EmployeeId = ?";
            java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);
            prepstmnt.setString(1, EmployeeIdTxtBox.getText());
            prepstmnt.setString(2, LastNameTxtBox.getText());
            prepstmnt.setString(3, FirstNameTxtBox.getText());
            prepstmnt.setString(4, MaritalStatComboBox.getSelectedItem().toString());
            prepstmnt.setString(5, GenderComboBox.getSelectedItem().toString());
            prepstmnt.setDate(6, new java.sql.Date(DoBDatePicker.getDate().getTime()));
            prepstmnt.setString(7, ContactNumTxtBox.getText());
            prepstmnt.setString(8, EmailAddTxtBox.getText());
            prepstmnt.setString(9, AddressText.getText());
            prepstmnt.setString(10, DepartmentTxtBox.getText());
            prepstmnt.setString(11, JobTitleTxtBox.getText());
            prepstmnt.setDate(12, new java.sql.Date(DoEDatePicker.getDate().getTime()));
            prepstmnt.setString(13, WEmailTxtBox.getText());
            prepstmnt.setString(14, WContactTxtBox.getText());
            prepstmnt.setString(15, String.valueOf(EmployeeToEdit.EmployeeId));                              
            prepstmnt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Employee with ID number "+EmployeeToEdit.EmployeeNum+" is updated");
            mainParent.remove(this);
            mainCL.show(mainParent, "2");                   
        } catch (ClassNotFoundException | SQLException e1){
            e1.printStackTrace();
        }
    }//GEN-LAST:event_jButton1MouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea AddressText;
    private javax.swing.JTextField ContactNumTxtBox;
    private javax.swing.JTextField DepartmentTxtBox;
    private com.toedter.calendar.JDateChooser DoBDatePicker;
    private com.toedter.calendar.JDateChooser DoEDatePicker;
    private javax.swing.JTextField EmailAddTxtBox;
    private javax.swing.JTextField EmployeeIdTxtBox;
    private javax.swing.JLabel ErrorLbl;
    private javax.swing.JTextField FirstNameTxtBox;
    private javax.swing.JComboBox<String> GenderComboBox;
    private javax.swing.JTextField JobTitleTxtBox;
    private javax.swing.JTextField LastNameTxtBox;
    private javax.swing.JComboBox<String> MaritalStatComboBox;
    private javax.swing.JTextField WContactTxtBox;
    private javax.swing.JTextField WEmailTxtBox;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
