
package darsbbqapp;

import java.awt.CardLayout;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.event.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


public class EmployeesPanel extends javax.swing.JPanel {

    public Employee SelectedEmployee;
    public JPanel mainParent;
    public CardLayout mainCL;
    public Account AccountIn;
    public EmployeesPanel(JPanel MainParent, CardLayout MainCL, Account accountIn) {
        initComponents();
        AccountIn = accountIn;
        mainParent = MainParent;
        mainCL = MainCL;
        AddressText.setEditable(false);
        SearchEmpTxtBox.setText("");
        SearchEmployee();
        SearchEmpTxtBox.getDocument().addDocumentListener(new DocumentListener() {
        public void changedUpdate(DocumentEvent e) {
            warn();
        }
        public void removeUpdate(DocumentEvent e) {
            warn();
        }
        public void insertUpdate(DocumentEvent e) {
            warn();
        }

        public void warn() {
            SearchEmployee();
        }
        });        
    }
    
    
    @SuppressWarnings("unchecked")
    private void SearchEmployee(){
        String Search = "%"+ SearchEmpTxtBox.getText() + "%";
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
            Statement st = con.createStatement();
            String query="select * from employee where EmployeeNum like ? or LastName like ? or FirstName like ? or Department like ? or JobTitle like ? or DateOfEmployment = ?";
            java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);
            for (int i = 1;i<7;i++){
                prepstmnt.setString(i, Search);               
            }           
            ResultSet rs= prepstmnt.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            DefaultTableModel model = (DefaultTableModel) EmployeeList.getModel();
            String[] colName = new String[7];
            colName[0]="EmployeeNum";
            colName[1]="EmployeeId";
            colName[2]="LastName";
            colName[3]="FirstName";
            colName[4]="DateOfBirth";
            colName[5]="JobTitle";
            colName[6]="Dept";
            model.setColumnIdentifiers(colName);
            String EmployeeId,EmployeeNum,LastName,FirstName,DateOfBirth,JobTitle,Dept;
            model.setRowCount(0);
            while(rs.next()){
                EmployeeId=rs.getString(1);
                EmployeeNum=rs.getString(3);
                LastName=rs.getString(4);
                FirstName=rs.getString(5);
                DateOfBirth=rs.getString(6);
                JobTitle=rs.getString(12);
                Dept=rs.getString(11);
                String[] row= {EmployeeId,EmployeeNum,LastName,FirstName,DateOfBirth,JobTitle,Dept};
                model.addRow(row);
            }
            st.close();
            con.close();
            
        } catch (ClassNotFoundException | SQLException e1){
            e1.printStackTrace();
        }
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        NameLbl = new javax.swing.JLabel();
        EmployeeNumLbl = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        DoBLbl = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        GenderLbl = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        MaritalStatLbl = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        ContactNumLbl = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        EmailLbl = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        AddressText = new javax.swing.JTextArea();
        jLabel8 = new javax.swing.JLabel();
        DepartmentLbl = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        JobLbl = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        DoELbl = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        WEmailLbl = new javax.swing.JLabel();
        WPhoneLbl = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        RemoveBtn = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        EmployeeList = new javax.swing.JTable();
        SearchEmpTxtBox = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        BackButton = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 204, 0));
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        jPanel1.setForeground(new java.awt.Color(102, 102, 102));

        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("Name ");

        NameLbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        NameLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        EmployeeNumLbl.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        EmployeeNumLbl.setForeground(new java.awt.Color(255, 153, 0));
        EmployeeNumLbl.setText("Employee Num");

        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setText("Date of Birth ");

        DoBLbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        DoBLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel3.setForeground(new java.awt.Color(102, 102, 102));
        jLabel3.setText("Gender ");

        GenderLbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        GenderLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel4.setForeground(new java.awt.Color(102, 102, 102));
        jLabel4.setText("Marital Status ");

        MaritalStatLbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        MaritalStatLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel5.setForeground(new java.awt.Color(102, 102, 102));
        jLabel5.setText("Contact# ");

        ContactNumLbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ContactNumLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel6.setForeground(new java.awt.Color(102, 102, 102));
        jLabel6.setText("Email ");

        EmailLbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        EmailLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel7.setForeground(new java.awt.Color(102, 102, 102));
        jLabel7.setText("Address ");

        AddressText.setBackground(new java.awt.Color(242, 242, 242));
        AddressText.setColumns(20);
        AddressText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        AddressText.setLineWrap(true);
        AddressText.setRows(5);
        AddressText.setBorder(null);
        AddressText.setFocusable(false);
        jScrollPane2.setViewportView(AddressText);

        jLabel8.setForeground(new java.awt.Color(102, 102, 102));
        jLabel8.setText("Department ");

        DepartmentLbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        DepartmentLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel9.setForeground(new java.awt.Color(102, 102, 102));
        jLabel9.setText("Job Title ");

        JobLbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        JobLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel10.setForeground(new java.awt.Color(102, 102, 102));
        jLabel10.setText("Date of Employment ");

        DoELbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        DoELbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel11.setForeground(new java.awt.Color(102, 102, 102));
        jLabel11.setText("Work Email ");

        jLabel12.setForeground(new java.awt.Color(102, 102, 102));
        jLabel12.setText("Work Phone# ");

        WEmailLbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        WEmailLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        WPhoneLbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        WPhoneLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jButton1.setText("Edit");
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        RemoveBtn.setForeground(new java.awt.Color(255, 0, 51));
        RemoveBtn.setText("Remove");
        RemoveBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        RemoveBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RemoveBtnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(EmployeeNumLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(8, 8, 8))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel7))
                                .addGap(46, 46, 46)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(DoBLbl, javax.swing.GroupLayout.DEFAULT_SIZE, 202, Short.MAX_VALUE)
                                            .addComponent(GenderLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(NameLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(MaritalStatLbl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(8, 8, 8))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jScrollPane2)
                                .addContainerGap())
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel9))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(JobLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(EmailLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(ContactNumLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(DepartmentLbl, javax.swing.GroupLayout.DEFAULT_SIZE, 202, Short.MAX_VALUE))
                                .addContainerGap())
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel12))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(WPhoneLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(WEmailLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(DoELbl, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE)))
                                .addContainerGap())
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(50, 50, 50)
                                .addComponent(RemoveBtn)
                                .addGap(58, 58, 58)
                                .addComponent(jButton1)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(EmployeeNumLbl)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(NameLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(DoBLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(GenderLbl))
                .addGap(8, 8, 8)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(MaritalStatLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(ContactNumLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(EmailLbl))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(DepartmentLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(JobLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(DoELbl))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(WEmailLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(WPhoneLbl)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 92, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RemoveBtn)
                    .addComponent(jButton1))
                .addGap(38, 38, 38))
        );

        jPanel3.setOpaque(false);
        jPanel3.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                jPanel3ComponentShown(evt);
            }
        });

        EmployeeList.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Employee Number", "Last Name", "First Name", "Date of Birth", "Job Title", "Department"
            }
        ));
        EmployeeList.setRowHeight(35);
        EmployeeList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EmployeeListMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(EmployeeList);

        SearchEmpTxtBox.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                SearchEmpTxtBoxPropertyChange(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/darsbbqapp/Photos/plus-icon-21715 (2).png"))); // NOI18N
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        BackButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BackButton.setText("<");
        BackButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BackButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BackButtonMouseClicked(evt);
            }
        });

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/darsbbqapp/Photos/icons8-search-20.png"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 666, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(BackButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SearchEmpTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(SearchEmpTxtBox)
                        .addComponent(BackButton)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 525, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void SearchEmpTxtBoxPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_SearchEmpTxtBoxPropertyChange

    }//GEN-LAST:event_SearchEmpTxtBoxPropertyChange

    private void EmployeeListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EmployeeListMouseClicked
        int i = EmployeeList.getSelectedRow();
        TableModel model = EmployeeList.getModel();
        int selectedId = Integer.parseInt(model.getValueAt(i,0).toString());
        int employeeId = 0, isadmin = 0, accountId = 0;
        String employeeNum = null,lastName = null,firstName = null,maritalStat = null,gender = null,cNum = null,email = null,address = null,dept = null,jobTitle = null,wEmail = null,wPhone = null;
        Date dob=null,doe=null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
            Statement st = con.createStatement();
            String query="select * from employee Inner Join account on (employee.AccountId = account.AccountID or employee.AccountId is null) where EmployeeId = ?"; 
            java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);
            prepstmnt.setInt(1,selectedId);
            ResultSet rs= prepstmnt.executeQuery();                       
            if(rs.next()){
                employeeId = rs.getInt(1);
                accountId = rs.getInt(2);              
                employeeNum = rs.getString(3);
                lastName = rs.getString(4);
                firstName = rs.getString(5);
                maritalStat = rs.getString(6);
                gender = rs.getString(7);
                dob = rs.getDate(8);
                cNum = rs.getString(9);
                email = rs.getString(10);
                address = rs.getString(11);
                dept = rs.getString(12);
                jobTitle = rs.getString(13);
                doe = rs.getDate(14);
                wEmail = rs.getString(15);
                wPhone = rs.getString(16);
                isadmin = rs.getInt(20);
            }
            EmployeeNumLbl.setText(employeeNum);
            NameLbl.setText(lastName+", "+firstName);
            MaritalStatLbl.setText(maritalStat);
            GenderLbl.setText(gender);
            DoBLbl.setText(dob.toString());
            ContactNumLbl.setText(cNum);
            EmailLbl.setText(email);
            AddressText.setText(address);                     
            DepartmentLbl.setText(dept);
            JobLbl.setText(jobTitle);
            DoELbl.setText(doe.toString());
            WEmailLbl.setText(wEmail);
            WPhoneLbl.setText(wPhone);
            SelectedEmployee = new Employee(employeeId,accountId,employeeNum,lastName,firstName,maritalStat,gender,dob,cNum,email,address,dept,jobTitle,doe,wEmail,wPhone,isadmin);
            st.close();
            con.close();
            }catch (ClassNotFoundException | SQLException e1){
            e1.printStackTrace();
        }
                    
    }//GEN-LAST:event_EmployeeListMouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        if (AccountIn.IsAdmin == false && SelectedEmployee.isAdmin == true){
            JOptionPane.showMessageDialog(null, "This employee is an admin and can only be edited by an account with admin privileges...", "Security",JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if (SelectedEmployee != null){
            mainParent.add(new EditEmployee(SelectedEmployee,mainParent,mainCL),"NewEditEmployee");
            mainCL.show(mainParent, "NewEditEmployee");           
        }       
    }//GEN-LAST:event_jButton1MouseClicked

    private void jPanel3ComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jPanel3ComponentShown

    }//GEN-LAST:event_jPanel3ComponentShown

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        SearchEmployee();
    }//GEN-LAST:event_formComponentShown

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
        mainParent.add(new AddEmployee(mainParent,mainCL),"NewAddEmployee");
        mainCL.show(mainParent, "NewAddEmployee"); 
    }//GEN-LAST:event_jButton3MouseClicked

    private void BackButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BackButtonMouseClicked
        mainCL.show(mainParent, "1"); 
    }//GEN-LAST:event_BackButtonMouseClicked

    private void RemoveBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RemoveBtnMouseClicked
        if (AccountIn.IsAdmin == false && SelectedEmployee.isAdmin == true){
            JOptionPane.showMessageDialog(null, "This employee is an admin and can only be removed by an account with admin privileges...", "Security",JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int answer = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete Employee with the ID "+SelectedEmployee.EmployeeNum+ "? Employee data will be lost forever...", "Delete Confirmation", JOptionPane.YES_NO_OPTION);
        if (answer == 0){
            try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
            Statement st = con.createStatement();
            String query="delete from employee where EmployeeId = ?"; 
            java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);
            prepstmnt.setInt(1,SelectedEmployee.EmployeeId);
            prepstmnt.executeUpdate();
            if (SelectedEmployee.AccountId != 0){
                query="delete from account where AccountID = ?"; 
                prepstmnt = con.prepareStatement(query);
                prepstmnt.setInt(1,SelectedEmployee.AccountId);
                prepstmnt.executeUpdate();
            }
            JOptionPane.showMessageDialog(null, "Employee with ID number "+SelectedEmployee.EmployeeNum+" is now deleted from records...");
            SearchEmployee();
            }catch (ClassNotFoundException | SQLException e1){
            e1.printStackTrace();
        }                    
        }
    }//GEN-LAST:event_RemoveBtnMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea AddressText;
    private javax.swing.JButton BackButton;
    private javax.swing.JLabel ContactNumLbl;
    private javax.swing.JLabel DepartmentLbl;
    private javax.swing.JLabel DoBLbl;
    private javax.swing.JLabel DoELbl;
    private javax.swing.JLabel EmailLbl;
    private javax.swing.JTable EmployeeList;
    private javax.swing.JLabel EmployeeNumLbl;
    private javax.swing.JLabel GenderLbl;
    private javax.swing.JLabel JobLbl;
    private javax.swing.JLabel MaritalStatLbl;
    private javax.swing.JLabel NameLbl;
    private javax.swing.JButton RemoveBtn;
    private javax.swing.JTextField SearchEmpTxtBox;
    private javax.swing.JLabel WEmailLbl;
    private javax.swing.JLabel WPhoneLbl;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
