/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package darsbbqapp;

import java.util.Date;

/**
 *
 * @author Martin
 */
public class AccountDetails {
    public int AccountId;
    public int EmployeeId;
    public String LastName;
    public String FirstName;
    public Date DoB;
    public String Gender;
    public String JobTitle;
    public String Department;
    public String PhoneNum;
    public String Email;
    public String WEmail;
    public String WPhoneNum;
    public String Address;
    public String Username;
    public String Password;
    public AccountDetails(int accountId, int employeeId,String lastName,String firstName,String gender,Date dob,String phoneNum, String email,String address,String department,String jobTitle,String wEmail,String wPhone,String userName,String passWord){
        AccountId = accountId;
        EmployeeId = employeeId;
        LastName = lastName;
        FirstName = firstName;
        Gender = gender;
        DoB = dob;
        PhoneNum = phoneNum;
        Email = email;
        Address = address;
        Department = department;
        JobTitle = jobTitle;
        WEmail = wEmail;
        WPhoneNum = wPhone;
        Username = userName;
        Password = passWord;    
    }
}
