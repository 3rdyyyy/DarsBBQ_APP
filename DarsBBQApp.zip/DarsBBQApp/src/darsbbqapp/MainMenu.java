/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package darsbbqapp;

import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*;

/**
 *
 * @author Martin
 */
public class MainMenu extends javax.swing.JFrame {
    
    public static Account AccountIn;

    public CardLayout cl = new CardLayout();
    public MainMenu(Account accountIn) {
        AccountIn = accountIn;
        initComponents();
        MyInitComponents();
    }
    public void MyInitComponents(){ 
        MainContentPanel.setLayout(cl);
        MainContentPanel.add(new MainMenuPanel(AccountIn,this,MainContentPanel,cl),"1");
        MainContentPanel.add(new EmployeesPanel(MainContentPanel,cl,AccountIn),"2");
        MainContentPanel.add(new InventoryPanel(MainContentPanel,cl),"3");
        MainContentPanel.add(new Menu(MainContentPanel,cl),"4");
        MainContentPanel.add(new RestockHistory(MainContentPanel,cl),"5");
    }    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jMenu1 = new javax.swing.JMenu();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        MainContentPanel = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu5 = new javax.swing.JMenu();
        ManageAccountMenu = new javax.swing.JMenuItem();
        OptionsMenu = new javax.swing.JMenu();
        ClearEmployeeMenu = new javax.swing.JMenuItem();
        ClearInventoryMenu = new javax.swing.JMenuItem();
        ClearRestockHistoryMenu = new javax.swing.JMenuItem();
        ClearAllMenu = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();

        jMenu1.setText("jMenu1");

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 102, 0));

        MainContentPanel.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout MainContentPanelLayout = new javax.swing.GroupLayout(MainContentPanel);
        MainContentPanel.setLayout(MainContentPanelLayout);
        MainContentPanelLayout.setHorizontalGroup(
            MainContentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 979, Short.MAX_VALUE)
        );
        MainContentPanelLayout.setVerticalGroup(
            MainContentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 558, Short.MAX_VALUE)
        );

        jMenuBar1.setMaximumSize(new java.awt.Dimension(116, 23));

        jMenu5.setBorder(null);
        jMenu5.setText("Security");
        jMenu5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        ManageAccountMenu.setText("Manage Accounts");
        ManageAccountMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ManageAccountMenuMouseClicked(evt);
            }
        });
        ManageAccountMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ManageAccountMenuActionPerformed(evt);
            }
        });
        jMenu5.add(ManageAccountMenu);

        jMenuBar1.add(jMenu5);

        OptionsMenu.setBorder(null);
        OptionsMenu.setText("Admin Tools");
        OptionsMenu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        OptionsMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OptionsMenuMouseClicked(evt);
            }
        });

        ClearEmployeeMenu.setForeground(new java.awt.Color(255, 0, 0));
        ClearEmployeeMenu.setText("Clear all Employee Data");
        ClearEmployeeMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ClearEmployeeMenuMouseClicked(evt);
            }
        });
        ClearEmployeeMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearEmployeeMenuActionPerformed(evt);
            }
        });
        OptionsMenu.add(ClearEmployeeMenu);

        ClearInventoryMenu.setForeground(new java.awt.Color(255, 0, 0));
        ClearInventoryMenu.setText("Clear all Inventory Data");
        ClearInventoryMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ClearInventoryMenuMouseClicked(evt);
            }
        });
        ClearInventoryMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearInventoryMenuActionPerformed(evt);
            }
        });
        OptionsMenu.add(ClearInventoryMenu);

        ClearRestockHistoryMenu.setForeground(new java.awt.Color(255, 0, 0));
        ClearRestockHistoryMenu.setText("Clear all Restock History");
        ClearRestockHistoryMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ClearRestockHistoryMenuMouseClicked(evt);
            }
        });
        ClearRestockHistoryMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearRestockHistoryMenuActionPerformed(evt);
            }
        });
        OptionsMenu.add(ClearRestockHistoryMenu);

        ClearAllMenu.setForeground(new java.awt.Color(255, 0, 0));
        ClearAllMenu.setText("Clear All Data");
        ClearAllMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearAllMenuActionPerformed(evt);
            }
        });
        OptionsMenu.add(ClearAllMenu);

        jMenuBar1.add(OptionsMenu);

        jMenu3.setBorder(null);
        jMenu3.setText("About");
        jMenu3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jMenu3.setFocusable(false);

        jMenuItem4.setText("Version 1.0");
        jMenuItem4.setEnabled(false);
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem4);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MainContentPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MainContentPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ClearInventoryMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearInventoryMenuActionPerformed
        if (AccountIn.IsAdmin == false){
            JOptionPane.showMessageDialog(null, "This action is only reserved to accounts with admin privileges...", "Security",JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int answer = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete all Inventory records?", "Delete Confirmation", JOptionPane.YES_NO_OPTION);
        if (answer == 0){
            try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
                Statement st = con.createStatement();
                String query="delete from inventory";
                java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);               
                prepstmnt.executeUpdate();
                JOptionPane.showMessageDialog(null, "All Inventory records are now removed...");
            }catch (ClassNotFoundException | SQLException e1){
                e1.printStackTrace();
            }
        }
    }//GEN-LAST:event_ClearInventoryMenuActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void ClearAllMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearAllMenuActionPerformed
        if (AccountIn.IsAdmin == false){
            JOptionPane.showMessageDialog(null, "This action is only reserved to accounts with admin privileges...", "Security",JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int answer = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete all records? (Employees linked to admin accounts will not be deleted. Go to Securit>Manage accounts to delete.)", "Delete Confirmation", JOptionPane.YES_NO_OPTION);
        if (answer == 0){
            try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
                Statement st = con.createStatement();
                String query="delete from employee where employee.AccountId is null or employee.AccountId not in (Select account.AccountID from account where account.isAdmin = 1)";
                java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);               
                prepstmnt.executeUpdate();
                query="delete from account where account.isAdmin = 0";
                prepstmnt = con.prepareStatement(query);               
                prepstmnt.executeUpdate();
                query="delete from inventory";
                prepstmnt = con.prepareStatement(query);               
                prepstmnt.executeUpdate();
                JOptionPane.showMessageDialog(null, "All records are now removed...");
                cl.show(MainContentPanel,"1");
            }catch (ClassNotFoundException | SQLException e1){
                e1.printStackTrace();
            }
        }
    }//GEN-LAST:event_ClearAllMenuActionPerformed

    private void OptionsMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OptionsMenuMouseClicked

    }//GEN-LAST:event_OptionsMenuMouseClicked

    private void ClearInventoryMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ClearInventoryMenuMouseClicked
        if (AccountIn.IsAdmin == false){
            JOptionPane.showMessageDialog(null, "This action is only reserved to accounts with admin privileges...", "Security",JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int answer = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete all Inventory records?", "Delete Confirmation", JOptionPane.YES_NO_OPTION);
        if (answer == 0){
            try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
                Statement st = con.createStatement();
                String query="delete from inventory";
                java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);               
                prepstmnt.executeUpdate();
                JOptionPane.showMessageDialog(null, "All Inventory records are now removed...");
                cl.show(MainContentPanel,"1");
            }catch (ClassNotFoundException | SQLException e1){
                e1.printStackTrace();
            }
        }
    }//GEN-LAST:event_ClearInventoryMenuMouseClicked

    private void ClearEmployeeMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ClearEmployeeMenuMouseClicked
      
    }//GEN-LAST:event_ClearEmployeeMenuMouseClicked

    private void ClearEmployeeMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearEmployeeMenuActionPerformed
        if (AccountIn.IsAdmin == false){
            JOptionPane.showMessageDialog(null, "This action is only reserved to accounts with admin privileges...", "Security",JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int answer = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete all Employee records? (Employees linked to admin accounts will not be deleted)", "Delete Confirmation", JOptionPane.YES_NO_OPTION);
        if (answer == 0){
            try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
                Statement st = con.createStatement();
                String query="delete from employee where employee.AccountId is null or employee.AccountId not in (Select account.AccountID from account where account.isAdmin = 1)";
                java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);               
                prepstmnt.executeUpdate();
                query="delete from account where account.isAdmin = 0";
                prepstmnt = con.prepareStatement(query);               
                prepstmnt.executeUpdate();
                JOptionPane.showMessageDialog(null, "All employee data are now removed...");
                cl.show(MainContentPanel,"1");
            }catch (ClassNotFoundException | SQLException e1){
                e1.printStackTrace();
            }
        }
    }//GEN-LAST:event_ClearEmployeeMenuActionPerformed

    private void ManageAccountMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ManageAccountMenuMouseClicked
       
    }//GEN-LAST:event_ManageAccountMenuMouseClicked

    private void ManageAccountMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ManageAccountMenuActionPerformed
        if (AccountIn.IsAdmin == false){
            JOptionPane.showMessageDialog(null, "This action is only reserved to accounts with admin privileges...", "Security",JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        JFrame NextWindow = new AccountManager();
        NextWindow.setTitle("Account Manager");
        NextWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        NextWindow.setSize(1100,800);
        NextWindow.setLocationRelativeTo(null);
        NextWindow.setVisible(true);
    }//GEN-LAST:event_ManageAccountMenuActionPerformed

    private void ClearRestockHistoryMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ClearRestockHistoryMenuMouseClicked
      
    }//GEN-LAST:event_ClearRestockHistoryMenuMouseClicked

    private void ClearRestockHistoryMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearRestockHistoryMenuActionPerformed
        if (AccountIn.IsAdmin == false){
            JOptionPane.showMessageDialog(null, "This action is only reserved to accounts with admin privileges...", "Security",JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int answer = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete all Restock records?", "Delete Confirmation", JOptionPane.YES_NO_OPTION);
        if (answer == 0){
            try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq","root","");
                Statement st = con.createStatement();
                String query="delete from restock";
                java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);               
                prepstmnt.executeUpdate();
                JOptionPane.showMessageDialog(null, "All Restock records are now removed...");
                cl.show(MainContentPanel,"1");
            }catch (ClassNotFoundException | SQLException e1){
                e1.printStackTrace();
            }
        }
    }//GEN-LAST:event_ClearRestockHistoryMenuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainMenu(AccountIn).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem ClearAllMenu;
    private javax.swing.JMenuItem ClearEmployeeMenu;
    private javax.swing.JMenuItem ClearInventoryMenu;
    private javax.swing.JMenuItem ClearRestockHistoryMenu;
    private javax.swing.JPanel MainContentPanel;
    private javax.swing.JMenuItem ManageAccountMenu;
    private javax.swing.JMenu OptionsMenu;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JPopupMenu jPopupMenu1;
    // End of variables declaration//GEN-END:variables
}
