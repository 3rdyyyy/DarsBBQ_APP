/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package darsbbqapp;

import java.util.Date;

/**
 *
 * @author Martin
 */
public class Employee {
    public int EmployeeId;
    public int AccountId;
    public String EmployeeNum;
    public String LastName;
    public String FirstName;
    public String MaritalStatus;
    public String Gender;
    public Date DateOfBirth; 
    public String ContactNum;
    public String Email;
    public String Address;
    public String Department;
    public String JobTitle;
    public Date DateOfEmployment;
    public String WEmail;
    public String WPhone;
    public boolean isAdmin;
    
    public Employee(int employeeId,int accountId, String employeeNum, String lastName,String firstName, String maritalStatus, String gender, Date dob, 
            String contactNum, String email, String address, String department, String jobTitle, Date doe, String workEmail, String workPhone, int isadmin){
        EmployeeId = employeeId;
        AccountId = accountId;
        EmployeeNum = employeeNum;
        LastName = lastName;
        FirstName = firstName;
        MaritalStatus = maritalStatus;
        Gender = gender;
        DateOfBirth = dob;
        ContactNum = contactNum;
        Email = email;
        Address = address;
        Department = department;
        JobTitle = jobTitle;
        DateOfEmployment = doe;
        WEmail = workEmail;
        WPhone = workPhone;
        if (isadmin == 1) isAdmin = true;
        else isAdmin = false;
    }
    
    
}
