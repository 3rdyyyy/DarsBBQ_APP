/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package darsbbqapp;

import static darsbbqapp.MainWindow.mainWindow;
import java.awt.CardLayout;
import java.awt.Color;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Martin
 */
public class AccountPanel extends javax.swing.JPanel {

    public CardLayout mainCL;
    public JPanel mainParent;
    public AccountDetails AccountEdit;
    public Account AccountIn;
    
    public AccountPanel(Account accountIn, CardLayout MainCL, JPanel MainParent) {
        mainParent = MainParent;
        mainCL = MainCL;
        AccountIn = accountIn;
        initComponents();       
    }
    public void LoadAccount(){
        int employeeId = 0, accountId = 0;
        String employeeNum = null,lastName = null,firstName = null,gender = null,cNum = null,email = null,address = null,dept = null,jobTitle = null,wEmail = null,wPhone = null, username = null, password = null;
        Date dob=null,doe=null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/darsbbq", "root", "");
            String query = "Select * from employee Inner Join account on (employee.AccountId = account.AccountID) where employee.AccountId = ?";
            java.sql.PreparedStatement prepstmnt = con.prepareStatement(query);
            prepstmnt.setInt(1, AccountIn.AccountId);
            ResultSet rs= prepstmnt.executeQuery();
            if(rs.next()){
                employeeId = rs.getInt(1);
                accountId = rs.getInt(2);
                employeeNum = rs.getString(3);
                lastName = rs.getString(4);
                firstName = rs.getString(5);               
                gender = rs.getString(7);
                dob = rs.getDate(8);
                cNum = rs.getString(9);
                email = rs.getString(10);
                address = rs.getString(11);
                dept = rs.getString(12);
                jobTitle = rs.getString(13);
                doe = rs.getDate(14);
                wEmail = rs.getString(15);
                wPhone = rs.getString(16);
                username = rs.getString(18);
                password = rs.getString(19);
            }
            NameLbl.setText(lastName+", "+ firstName);
            genderLbl.setText(gender);
            dobLbl.setText(dob.toString());
            JobLbl.setText(jobTitle);
            DeptLbl.setText(dept);
            EmailLbl.setText(email);
            ContactLbl.setText(cNum);
            WEmailLbl.setText(wEmail);
            WPhoneLbl.setText(wPhone);
            UserNameLbl.setText(username); 
            AccountEdit = new AccountDetails(accountId,employeeId,lastName,firstName,gender,dob,cNum,email,address,dept,jobTitle,wEmail,wPhone,username,password);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(AccountPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        NameLbl = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        dobLbl = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        genderLbl = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        JobLbl = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        EmailLbl = new javax.swing.JLabel();
        ContactLbl = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        WEmailLbl = new javax.swing.JLabel();
        WPhoneLbl = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        UserNameLbl = new javax.swing.JLabel();
        jlabel12 = new javax.swing.JLabel();
        DeptLbl = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 204, 0));
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 10, true));

        NameLbl.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        NameLbl.setText("Name Here");
        NameLbl.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        NameLbl.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(204, 204, 204)));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Date of Birth");

        dobLbl.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        dobLbl.setText("DOB Here");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Gender");

        genderLbl.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        genderLbl.setText("jLabel4");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("Position");

        JobLbl.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        JobLbl.setText("JobTitle Here");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Personal Contacts");

        EmailLbl.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        EmailLbl.setText("jLabel5");

        ContactLbl.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ContactLbl.setText("jLabel5");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setText("Work Contacts");

        WEmailLbl.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        WEmailLbl.setText("jLabel6");

        WPhoneLbl.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        WPhoneLbl.setText("jLabel6");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("Username");

        UserNameLbl.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        UserNameLbl.setText("jLabel7");

        jlabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jlabel12.setText("Department");

        DeptLbl.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        DeptLbl.setText("jLabel7");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(NameLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(dobLbl)
                            .addComponent(jLabel4)
                            .addComponent(EmailLbl)
                            .addComponent(ContactLbl)
                            .addComponent(jLabel3)
                            .addComponent(genderLbl))
                        .addGap(58, 58, 58)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(DeptLbl)
                            .addComponent(jlabel12)
                            .addComponent(WEmailLbl)
                            .addComponent(WPhoneLbl)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel2)
                                    .addComponent(JobLbl))
                                .addGap(68, 68, 68)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(UserNameLbl)
                                    .addComponent(jLabel6))))
                        .addGap(0, 287, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(NameLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dobLbl)
                    .addComponent(JobLbl)
                    .addComponent(UserNameLbl))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jlabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(genderLbl)
                    .addComponent(DeptLbl))
                .addGap(46, 46, 46)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EmailLbl)
                    .addComponent(WEmailLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(WPhoneLbl)
                    .addComponent(ContactLbl))
                .addGap(0, 6, Short.MAX_VALUE))
        );

        jPanel2.setOpaque(false);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/darsbbqapp/Photos/icons8-edit-20.png"))); // NOI18N
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton1))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 117, Short.MAX_VALUE)
                .addComponent(jButton1))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked

        mainParent.add(new EditAccountPanel(AccountEdit,mainParent,mainCL),"NewEditAccount");
        mainCL.show(mainParent, "NewEditAccount");
    }//GEN-LAST:event_jButton1MouseClicked

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        LoadAccount();
    }//GEN-LAST:event_formComponentShown


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ContactLbl;
    private javax.swing.JLabel DeptLbl;
    private javax.swing.JLabel EmailLbl;
    private javax.swing.JLabel JobLbl;
    private javax.swing.JLabel NameLbl;
    private javax.swing.JLabel UserNameLbl;
    private javax.swing.JLabel WEmailLbl;
    private javax.swing.JLabel WPhoneLbl;
    private javax.swing.JLabel dobLbl;
    private javax.swing.JLabel genderLbl;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel jlabel12;
    // End of variables declaration//GEN-END:variables
}
